package com.example.tax_amount;

public class Calculate_tax {
    private float total_Salary;
    private float total_tax, tax1, tax2, tax3;
    public Calculate_tax(float salary) {
        total_Salary = salary * 12;
    }

    public float getTotal_Salary() {
        return total_Salary;
    }

    public void setTotal_Salary(float total_Salary) {
        this.total_Salary = total_Salary;
    }

    public float getTotal_tax() {
        return total_tax;
    }

    public void setTotal_tax(float total_tax) {
        this.total_tax = total_tax;
    }

    public float calculateTax(){
        if(total_Salary<=200000){
            tax1=total_Salary/100;
            return tax1;
        }else  if(total_Salary>=200000 && total_Salary<=350000){
            tax1=(200000*1)/100;
            total_Salary= total_Salary-200000;
            tax2=(total_Salary*15)/100;
            return tax1+tax2;
        }else if(total_Salary>=350000){
            tax1=(200000*1)/100;
            total_Salary= total_Salary-200000;
            tax2=(150000*15)/100;
            total_Salary= total_Salary-150000;
            tax3=(total_Salary*25)/100;
            return tax1+tax2+tax3;
        }
        return 0;
    }
}

