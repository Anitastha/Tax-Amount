package com.example.tax_amount;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText eSalary;
    private TextView tTotalTax, tTotalSalary;
    private Button btnCalculation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eSalary = findViewById(R.id.editSalary);
        tTotalSalary = findViewById(R.id.totalSalary);
        tTotalTax = findViewById(R.id.totalTax);
        btnCalculation = findViewById(R.id.btnCalculate);
        btnCalculation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Validation() == true) {
                    float salary;
                    salary = Float.parseFloat(eSalary.getText().toString());
                    Calculate_tax tax = new Calculate_tax(salary);
                    tTotalSalary.setText(Float.toString(tax.getTotal_Salary()));
                    tTotalTax.setText(Float.toString(tax.calculateTax()));
                }
            }
        });
    }
    public Boolean Validation() {
        if (TextUtils.isEmpty(eSalary.getText())) {
            eSalary.requestFocus();
            eSalary.setError("Please Enter Salary");
            return false;
        }
        return true;
    }
}

